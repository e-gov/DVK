alter
table   dhl_settings
add
(    
    subdivision_code number(38,0) null,
    occupation_code number(38,0) null
)
/
