package org.castor.cpa.test.entity;

public final class Entity {
    private Integer _id;
    private String _name;
    
    public Integer getId() {
        return _id;
    }
    
    public void setId(final Integer id) {
        _id = id;
    }
    
    public String getName() {
        return _name;
    }
    
    public void setName(final String name) {
        _name = name;
    }
}
