ALTER
TABLE	dhl_settings
ADD	subdivision_code int NULL,
	occupation_code int NULL
GO
