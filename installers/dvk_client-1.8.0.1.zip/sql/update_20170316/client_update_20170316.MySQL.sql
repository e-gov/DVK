ALTER TABLE dhl_settings
ADD xroad_client_member_code VARCHAR(50);
