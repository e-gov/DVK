----------------------------------------------------------------------
-- February 2011
-- Rollback DVK Client from version 1.6.1 to 1.6.0
----------------------------------------------------------------------

drop procedure if exists "Delete_OldDhlMessages";
